<section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
	<div class="container">
		<div class="row justify-content-center">
		<div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">

			<div class="d-flex justify-content-center py-4">
			<a class="logo d-flex align-items-center w-auto">
				<img src="<?=base_url('assets');?>/img/valeo.png">
			</a>
			</div><!-- End Logo -->

			<div class="card mb-3">
				<div class="card-body">

					<div class="pt-3 pb-2">
					<h5 class="card-title text-center pb-0 fs-4">Login to Your Account</h5>
					<p class="text-center small">Enter your username & password</p>
					<br>
					</div>
					<?php if ($this->session->flashdata('registration') != '') { ?>
						<?= $this->session->flashdata('registration'); ?>
					<?php } ?>
					<?php if ($this->session->flashdata('logout') != '') { ?>
						<?= $this->session->flashdata('logout'); ?>
					<?php } ?>
					<?php if ($this->session->flashdata('wrong_username') != '') { ?>
						<?= $this->session->flashdata('wrong_username'); ?>
					<?php } ?>
					<?php if ($this->session->flashdata('not_active_username') != '') { ?>
						<?= $this->session->flashdata('not_active_username'); ?>
					<?php } ?>
					<?php if ($this->session->flashdata('wrong_password') != '') { ?>
						<?= $this->session->flashdata('wrong_password'); ?>
					<?php } ?>
					<?php if ($this->session->flashdata('success') != '') { ?>
						<?= $this->session->flashdata('success'); ?>
					<?php } ?>
					<form class="row g-3 needs-validation" method="post" action="<?=base_url('auth')?>">
						<div class="col-12">
							<label for="yourUsername" class="form-label">Username</label>
							<div class="input-group has-validation">
							<input type="text" name="username" class="form-control" id="yourUsername" required>
							<div class="invalid-feedback">Please enter your username.</div>
							</div>
						</div>
						<div class="col-12">
							<label for="yourPassword" class="form-label">Password</label>
							<input type="password" name="password" class="form-control" id="yourPassword" required>
							<div class="invalid-feedback">Please enter your password!</div>
						</div>
						<div class="col-12">
							<button class="btn btn-primary w-100" type="submit">Login</button>
							<p></p>
							<p class="text-center" style="font-size: 13px;">v1.0.0</p>
						</div>
					</form>
				</div>
			</div>
		</div>
		</div>
	</div>

</section>