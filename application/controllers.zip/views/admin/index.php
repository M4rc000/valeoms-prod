<section class="section dashboard">
  <div class="card">
    <div class="card-body">
      <div class="row mt-2">
        <img src="<?=base_url('assets');?>/img/valeo.jpg" style="border-radius: 40px;">
      </div>
    </div>
  </div>
</section>